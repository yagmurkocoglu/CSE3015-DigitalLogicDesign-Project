import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.constant.Constable;
import java.util.Objects;
import java.util.Scanner;

/*
Abdullah Enes Dizer / 150119880
Mert Efe Karaköse / 150119805
Mervan Aburşu / 150116015
Yağmur Koçoğlu / 150119715
 */

public class Main {

    public static String register(String reg) {

        switch (reg) {
            case "R0" -> {
                return "0000";
            }
            case "R1" -> {
                return "0001";
            }
            case "R2" -> {
                return "0010";
            }
            case "R3" -> {
                return "0011";
            }
            case "R4" -> {
                return "0100";
            }
            case "R5" -> {
                return "0101";
            }
            case "R6" -> {
                return "0110";
            }
            case "R7" -> {
                return "0111";
            }
            case "R8" -> {
                return "1000";
            }
            case "R9" -> {
                return "1001";
            }
            case "R10" -> {
                return "1010";
            }
            case "R11" -> {
                return "1011";
            }
            case "R12" -> {
                return "1100";
            }
            case "R13" -> {
                return "1101";
            }
            case "R14" -> {
                return "1110";
            }
            case "R15" -> {
                return "1111";
            }

        }
        return "Null";
    }

    public static String operatins(String ope) {

        switch (ope) {
            case "SUB" -> {
                return "00000";
            }
            case "ADD" -> {
                return "00001";
            }
            case "AND" -> {
                return "00010";
            }
            case "OR" -> {
                return "00011";
            }
            case "XOR" -> {
                return "00100";
            }
            case "ADDI" -> {
                return "00101";
            }
            case "SUBI" -> {
                return "00110";
            }
            case "ANDI" -> {
                return "00111";
            }
            case "ORI" -> {
                return "01000";
            }
            case "XORI" -> {
                return "01001";
            }
            case "LD" -> {
                return "01010";
            }
            case "ST" -> {
                return "01011";
            }
            case "JUMP" -> {
                return "01100";
            }
            case "PUSH" -> {
                return "01101";
            }
            case "POP" -> {
                return "01110";
            }
            case "BE" -> {
                return "01111";
            }
            case "BNE" -> {
                return "10000";
            }

        }
        return "Null";
    }

    public static String seven_bits(int decimal) {
        int[] binary = new int[7];
        String imm = "";
        int index = 0;
        while (decimal > 0) {
            binary[index++] = decimal % 2;
            decimal = decimal / 2;
        }
        for (int i = 6; i >= 0; i--) {
            imm = imm + binary[i];
        }
        return imm;
    }

    public static String ten_bits(int decimal) {
        int[] binary = new int[10];
        String addr = "";
        int index = 0;
        while (decimal > 0) {
            binary[index++] = decimal % 2;
            decimal = decimal / 2;
        }
        for (int i = 9; i >= 0; i--) {
            addr = addr + binary[i];
        }
        return addr;
    }


    public static void main(String[] args) {
        String data = null;
        try {
            File myObj = new File("input.txt");
            FileWriter myWriter = new FileWriter("output.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                data = myReader.nextLine();

                String[] operation = data.split(" ", 2);
                String hexa = "";
                if (Objects.equals(operation[0], "SUB")) {
                    String[] reg = operation[1].split(",", 3);
                    String binary = operatins(operation[0]) + register(reg[0]) + register(reg[1]) + register(reg[2]) + "000";
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "ADD")) {
                    String[] reg = operation[1].split(",", 3);
                    String binary = operatins(operation[0]) + register(reg[0]) + register(reg[1]) + register(reg[2]) + "000";
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "AND")) {
                    String[] reg = operation[1].split(",", 3);
                    String binary = operatins(operation[0]) + register(reg[0]) + register(reg[1]) + register(reg[2]) + "000";
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "OR")) {
                    String[] reg = operation[1].split(",", 3);
                    String binary = operatins(operation[0]) + register(reg[0]) + register(reg[1]) + register(reg[2]) + "000";
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "XOR")) {
                    String[] reg = operation[1].split(",", 3);
                    String binary = operatins(operation[0]) + register(reg[0]) + register(reg[1]) + register(reg[2]) + "000";
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "ADDI")) {
                    String[] reg = operation[1].split(",", 3);
                    String binary = operatins(operation[0]) + register(reg[0]) + register(reg[1]) + seven_bits(Integer.parseInt(reg[2]));
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "SUBI")) {
                    String[] reg = operation[1].split(",", 3);
                    String binary = operatins(operation[0]) + register(reg[0]) + register(reg[1]) + seven_bits(Integer.parseInt(reg[2]));
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "ANDI")) {
                    String[] reg = operation[1].split(",", 3);
                    String binary = operatins(operation[0]) + register(reg[0]) + register(reg[1]) + seven_bits(Integer.parseInt(reg[2]));
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "ORI")) {
                    String[] reg = operation[1].split(",", 3);
                    String binary = operatins(operation[0]) + register(reg[0]) + register(reg[1]) + seven_bits(Integer.parseInt(reg[2]));
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "XORI")) {
                    String[] reg = operation[1].split(",", 3);
                    String binary = operatins(operation[0]) + register(reg[0]) + register(reg[1]) + seven_bits(Integer.parseInt(reg[2]));
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "LD")) {
                    String[] reg = operation[1].split(",", 2);
                    String binary = operatins(operation[0]) + register(reg[0]) + ten_bits(Integer.parseInt(reg[1])) + "0";
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "ST")) {
                    String[] reg = operation[1].split(",", 2);
                    String binary = operatins(operation[0]) + register(reg[0]) + ten_bits(Integer.parseInt(reg[1])) + "0";
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "JUMP")) {
                    String binary = operatins(operation[0]) + ten_bits(Integer.parseInt(operation[1])) + "00000";
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "PUSH")) {
                    String binary = operatins(operation[0]) + register(operation[1]) + "00000000000";
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "POP")) {
                    String binary = operatins(operation[0]) + register(operation[1]) + "00000000000";
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "BE")) {
                    String[] reg = operation[1].split(",", 3);
                    String binary = operatins(operation[0]) + register(reg[0]) + register(reg[1]) + seven_bits(Integer.parseInt(reg[2]));
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                } else if (Objects.equals(operation[0], "BNE")) {
                    String[] reg = operation[1].split(",", 3);
                    String binary = operatins(operation[0]) + register(reg[0]) + register(reg[1]) + seven_bits(Integer.parseInt(reg[2]));
                    hexa = Integer.toHexString(Integer.parseInt(binary, 2));
                }
                myWriter.write(hexa+"\n");

            }
            myReader.close();
            myWriter.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

    }
}
